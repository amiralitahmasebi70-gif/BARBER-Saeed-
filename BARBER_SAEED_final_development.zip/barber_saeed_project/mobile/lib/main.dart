import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

const gold = Color(0xFFD6AD60);
const bg = Color(0xFF101010);
const panel = Color(0xFF1B1B1B);

// Change this to the public HTTPS address of your deployed backend.
const apiBase = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:3000');

void main() => runApp(const BarberSaeedApp());

class BarberSaeedApp extends StatelessWidget {
  const BarberSaeedApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'BARBER SAEED',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: gold, secondary: gold, surface: panel),
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: gold, centerTitle: true),
      useMaterial3: true,
      fontFamily: 'Roboto',
    ),
    home: const MainPage(),
  );
}

class Service {
  final String id, name, description;
  final int price, duration;
  const Service(this.id, this.name, this.description, this.price, this.duration);
}

const services = [
  Service('haircut', 'اصلاح مو', 'کوتاهی و فرم‌دهی مو', 150000, 30),
  Service('beard', 'اصلاح ریش', 'اصلاح و مرتب‌سازی ریش', 100000, 20),
  Service('facial', 'پاکسازی پوست', 'پاکسازی و رسیدگی به پوست', 200000, 45),
  Service('hair_beard', 'اصلاح مو و ریش', 'پکیج کامل اصلاح', 220000, 50),
  Service('groom', 'گریم داماد', 'آماده‌سازی ویژه داماد', 300000, 60),
  Service('special', 'خدمات ویژه', 'خدمات اختصاصی سالن', 0, 45),
];

class MainPage extends StatefulWidget {
  const MainPage({super.key});
  @override State<MainPage> createState() => _MainPageState();
}
class _MainPageState extends State<MainPage> {
  int tab = 0;
  Service? selected;
  DateTime? date;
  TimeOfDay? time;
  final phone = TextEditingController();

  String money(int n) => n == 0 ? 'قیمت توافقی' : '${NumberFormat('#,###').format(n)} تومان';

  Future<void> book() async {
    if (selected == null || date == null || time == null || phone.text.trim().length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('خدمت، تاریخ، ساعت و شماره موبایل را کامل کنید.')));
      return;
    }
    final start = DateTime(date!.year, date!.month, date!.day, time!.hour, time!.minute);
    try {
      final response = await http.post(Uri.parse('$apiBase/api/appointments'),
        headers: {'Content-Type':'application/json'},
        body: jsonEncode({'customerName':'مشتری','phone':phone.text.trim(),'serviceId':selected!.id,
          'barberId':'saeed','startAt':start.toIso8601String()}));
      if (!mounted) return;
      if (response.statusCode == 201) {
        showDialog(context: context, builder: (_) => AlertDialog(
          backgroundColor: panel, title: const Text('رزرو ثبت شد', textAlign: TextAlign.center),
          content: const Text('نوبت شما با موفقیت ثبت شد. برای قطعی بودن رزرو، پیام تأیید سامانه را بررسی کنید.', textAlign: TextAlign.center),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('متوجه شدم'))]));
      } else {
        final body = jsonDecode(response.body);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(body['error'] ?? 'امکان ثبت نوبت نیست.')));
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اتصال به سرور برقرار نشد. آدرس سرور را بررسی کنید.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _services(),
      _booking(),
      _profile(),
    ];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: const Text('BARBER SAEED', style: TextStyle(letterSpacing: 2, fontWeight: FontWeight.bold))),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        backgroundColor: panel, indicatorColor: gold.withOpacity(.18), selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.content_cut), label: 'خدمات'),
          NavigationDestination(icon: Icon(Icons.calendar_month), label: 'رزرو نوبت'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'پروفایل'),
        ]),
    ));
  }

  Widget _home() => ListView(padding: const EdgeInsets.all(20), children: [
    Container(height: 190, decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(22),
      gradient: const LinearGradient(colors: [Color(0xFF342719), Color(0xFF111111)], begin: Alignment.topRight, end: Alignment.bottomLeft),
      border: Border.all(color: gold.withOpacity(.55))),
      child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.content_cut, color: gold, size: 48),
        SizedBox(height: 12),
        Text('سعید شادکام', style: TextStyle(fontSize: 28, color: gold, fontWeight: FontWeight.bold)),
        Text('آرایشگاه مردانه | رزرو آنلاین', style: TextStyle(color: Colors.white70)),
      ])),
    const SizedBox(height: 22),
    FilledButton.icon(onPressed: () => setState(() => tab = 2),
      icon: const Icon(Icons.calendar_month), label: const Padding(padding: EdgeInsets.all(13), child: Text('رزرو نوبت جدید', style: TextStyle(fontSize: 17)))),
    const SizedBox(height: 24),
    const Text('خدمات محبوب', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: gold)),
    const SizedBox(height: 10),
    ...services.take(4).map(_serviceTile),
    const SizedBox(height: 12),
    const Card(color: panel, child: ListTile(leading: Icon(Icons.access_time, color: gold), title: Text('ساعات کاری'), subtitle: Text('ساعات کاری از طریق مدیریت سالن تنظیم می‌شود.'))),
  ]);

  Widget _services() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('خدمات ما', style: TextStyle(fontSize: 22, color: gold, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12), ...services.map(_serviceTile)
  ]);

  Widget _serviceTile(Service s) => Card(color: panel, child: ListTile(
    leading: const CircleAvatar(backgroundColor: Color(0xFF3A3020), child: Icon(Icons.content_cut, color: gold)),
    title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold)),
    subtitle: Text('${s.duration} دقیقه'),
    trailing: Text(money(s.price), style: const TextStyle(color: gold, fontWeight: FontWeight.bold)),
    onTap: () => setState(() { selected = s; tab = 2; }),
  ));

  Widget _booking() => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('رزرو نوبت', style: TextStyle(fontSize: 22, color: gold, fontWeight: FontWeight.bold)),
    const SizedBox(height: 18),
    const Text('۱. انتخاب خدمت'),
    const SizedBox(height: 8),
    DropdownButtonFormField<Service>(
      value: selected, dropdownColor: panel, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'خدمت موردنظر'),
      items: services.map((s) => DropdownMenuItem(value: s, child: Text(s.name))).toList(),
      onChanged: (v) => setState(() => selected = v)),
    const SizedBox(height: 18),
    const Text('۲. انتخاب تاریخ'),
    OutlinedButton.icon(onPressed: () async {
      final d = await showDatePicker(context: context, initialDate: DateTime.now().add(const Duration(days: 1)),
        firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 90)));
      if (d != null) setState(() => date = d);
    }, icon: const Icon(Icons.date_range), label: Text(date == null ? 'انتخاب تاریخ' : DateFormat('yyyy/MM/dd').format(date!))),
    const SizedBox(height: 12),
    const Text('۳. انتخاب ساعت'),
    OutlinedButton.icon(onPressed: () async {
      final t = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 10, minute: 0));
      if (t != null) setState(() => time = t);
    }, icon: const Icon(Icons.access_time), label: Text(time == null ? 'انتخاب ساعت' : time!.format(context))),
    const SizedBox(height: 18),
    const Text('۴. شماره موبایل'),
    TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(hintText: '09xxxxxxxxx', border: OutlineInputBorder())),
    const SizedBox(height: 18),
    if (selected != null) Text('مبلغ خدمت: ${money(selected!.price)}', style: const TextStyle(color: gold, fontSize: 17)),
    const SizedBox(height: 18),
    FilledButton(onPressed: book, child: const Padding(padding: EdgeInsets.all(14), child: Text('ثبت درخواست رزرو'))),
    const SizedBox(height: 10),
    const Text('توجه: ثبت نهایی و جلوگیری از تداخل نوبت‌ها باید توسط سرور انجام شود.', style: TextStyle(color: Colors.white54, fontSize: 12)),
  ]);

  Widget _profile() => const Center(child: Padding(padding: EdgeInsets.all(24), child: Column(
    mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.account_circle_outlined, size: 72, color: gold),
      SizedBox(height: 12), Text('پروفایل مشتری', style: TextStyle(fontSize: 22, color: gold)),
      SizedBox(height: 8), Text('سوابق رزرو و اطلاعات حساب پس از راه‌اندازی ورود پیامکی فعال می‌شود.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
    ])));
}
