const express = require('express');
const cors = require('cors');
const Database = require('better-sqlite3');
const path = require('path');
const app = express();
const db = new Database(process.env.DB_FILE || 'barber-saeed.sqlite');
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

db.exec(`
CREATE TABLE IF NOT EXISTS services (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, price INTEGER NOT NULL DEFAULT 0,
 duration INTEGER NOT NULL DEFAULT 30, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS weekly_schedule (
 weekday INTEGER PRIMARY KEY, is_open INTEGER NOT NULL DEFAULT 1, open_time TEXT NOT NULL DEFAULT '10:00', close_time TEXT NOT NULL DEFAULT '21:00', break_start TEXT, break_end TEXT
);
CREATE TABLE IF NOT EXISTS schedule_overrides (
 date TEXT PRIMARY KEY, is_open INTEGER NOT NULL DEFAULT 0, open_time TEXT, close_time TEXT, break_start TEXT, break_end TEXT, note TEXT
);
CREATE TABLE IF NOT EXISTS appointments (
 id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT NOT NULL,
 phone TEXT NOT NULL, service_id TEXT NOT NULL, barber_id TEXT NOT NULL DEFAULT 'saeed',
 start_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'confirmed',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
const scheduleInsert = db.prepare('INSERT OR IGNORE INTO weekly_schedule(weekday,is_open,open_time,close_time,break_start,break_end) VALUES(?,?,?,?,?,?)');
for (let day=0; day<7; day++) scheduleInsert.run(day, day===5 ? 0 : 1, '10:00', '21:00', '14:00', '15:00');

const defaults = [
 ['haircut','اصلاح مو',150000,30], ['beard','اصلاح ریش',100000,20],
 ['facial','پاکسازی پوست',200000,45], ['hair_beard','اصلاح مو و ریش',220000,50],
 ['groom','گریم داماد',300000,60], ['special','خدمات ویژه',0,45]
];
const add = db.prepare('INSERT OR IGNORE INTO services(id,name,price,duration) VALUES(?,?,?,?)');
defaults.forEach(x => add.run(...x));

// Tehran-local date/time helpers. API accepts ISO timestamps from the mobile app.
function tehranParts(date) {
 const parts = new Intl.DateTimeFormat('en-GB', {timeZone:'Asia/Tehran', weekday:'short', year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', hourCycle:'h23'}).formatToParts(date);
 const v = Object.fromEntries(parts.map(p=>[p.type,p.value]));
 const days = {Sun:0,Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6};
 return {weekday:days[v.weekday], date:`${v.year}-${v.month}-${v.day}`, minute:Number(v.hour)*60+Number(v.minute)};
}
function parseClock(value) { if (!value) return null; const m=/^(\d{2}):(\d{2})$/.exec(value); return m ? Number(m[1])*60+Number(m[2]) : null; }
function insideWindow(start, end, a, b) { return a != null && b != null && start >= a && end <= b; }
function checkBusinessHours(start, end) {
 const p=tehranParts(start);
 const override=db.prepare('SELECT * FROM schedule_overrides WHERE date=?').get(p.date);
 const schedule=override || db.prepare('SELECT * FROM weekly_schedule WHERE weekday=?').get(p.weekday);
 if (!schedule || !schedule.is_open) return 'این روز تعطیل است.';
 const open=parseClock(schedule.open_time), close=parseClock(schedule.close_time);
 if (!insideWindow(p.minute, p.minute + Math.round((end-start)/60000), open, close)) return 'این ساعت خارج از ساعات کاری آرایشگاه است.';
 const bs=parseClock(schedule.break_start), be=parseClock(schedule.break_end);
 if (bs != null && be != null && p.minute < be && p.minute + Math.round((end-start)/60000) > bs) return 'این زمان با ساعت استراحت تداخل دارد.';
 return null;
}

app.get('/api/admin/schedule', (_,res) => {
 res.json(db.prepare('SELECT * FROM weekly_schedule ORDER BY weekday').all());
});
app.put('/api/admin/schedule/:weekday', (req,res) => {
 const day = Number(req.params.weekday);
 const {isOpen, openTime, closeTime, breakStart, breakEnd} = req.body || {};
 if (!Number.isInteger(day) || day<0 || day>6 || !/^([01]\d|2[0-3]):[0-5]\d$/.test(openTime||'') || !/^([01]\d|2[0-3]):[0-5]\d$/.test(closeTime||'')) return res.status(400).json({error:'اطلاعات ساعت معتبر نیست.'});
 db.prepare('UPDATE weekly_schedule SET is_open=?,open_time=?,close_time=?,break_start=?,break_end=? WHERE weekday=?').run(isOpen?1:0,openTime,closeTime,breakStart||null,breakEnd||null,day);
 res.json({ok:true});
});
app.put('/api/admin/overrides/:date', (req,res) => {
 const date=req.params.date;
 if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return res.status(400).json({error:'تاریخ باید به شکل YYYY-MM-DD باشد.'});
 const {isOpen=false,openTime=null,closeTime=null,breakStart=null,breakEnd=null,note=''}=req.body||{};
 if (isOpen && (!/^([01]\d|2[0-3]):[0-5]\d$/.test(openTime||'') || !/^([01]\d|2[0-3]):[0-5]\d$/.test(closeTime||''))) return res.status(400).json({error:'ساعت شروع و پایان معتبر نیست.'});
 db.prepare(`INSERT INTO schedule_overrides(date,is_open,open_time,close_time,break_start,break_end,note) VALUES(?,?,?,?,?,?,?)
 ON CONFLICT(date) DO UPDATE SET is_open=excluded.is_open,open_time=excluded.open_time,close_time=excluded.close_time,break_start=excluded.break_start,break_end=excluded.break_end,note=excluded.note`).run(date,isOpen?1:0,openTime,closeTime,breakStart,breakEnd,note);
 res.json({ok:true});
});
app.get('/api/admin/overrides/:date', (req,res) => res.json(db.prepare('SELECT * FROM schedule_overrides WHERE date=?').get(req.params.date)||null));

app.get('/api/health', (_,res) => res.json({ok:true, app:'BARBER SAEED'}));
app.get('/api/services', (_,res) => res.json(db.prepare('SELECT * FROM services WHERE active=1 ORDER BY rowid').all()));
app.post('/api/appointments', (req,res) => {
 const {customerName, phone, serviceId, barberId='saeed', startAt} = req.body || {};
 if (!customerName || !phone || !serviceId || !startAt) return res.status(400).json({error:'اطلاعات رزرو کامل نیست.'});
 const service = db.prepare('SELECT * FROM services WHERE id=? AND active=1').get(serviceId);
 if (!service) return res.status(400).json({error:'خدمت انتخاب‌شده معتبر نیست.'});
 const start = new Date(startAt);
 if (isNaN(start.getTime()) || start < new Date()) return res.status(400).json({error:'تاریخ یا ساعت معتبر نیست.'});
 const end = new Date(start.getTime() + service.duration*60000);
 const scheduleError=checkBusinessHours(start,end);
 if (scheduleError) return res.status(400).json({error:scheduleError});
 const createBooking = db.transaction(() => {
   const overlap = db.prepare(`SELECT id FROM appointments WHERE barber_id=? AND status='confirmed'
     AND datetime(start_at) < datetime(?) AND datetime(start_at, '+' || (SELECT duration FROM services WHERE id=appointments.service_id) || ' minutes') > datetime(?)`)
     .get(barberId, end.toISOString(), start.toISOString());
   if (overlap) return null;
   return db.prepare(`INSERT INTO appointments(customer_name,phone,service_id,barber_id,start_at) VALUES(?,?,?,?,?)`)
     .run(customerName,phone,serviceId,barberId,start.toISOString());
 });
 const result=createBooking();
 if (!result) return res.status(409).json({error:'این ساعت قبلاً رزرو شده است. لطفاً ساعت دیگری انتخاب کنید.'});
 res.status(201).json({id:result.lastInsertRowid,status:'confirmed',payment:'pay_in_person'});
});
app.get('/api/admin/appointments', (req,res) => {
 // Protect this route with real admin authentication before public deployment.
 const rows = db.prepare(`SELECT a.*, s.name AS service_name, s.price, s.duration
   FROM appointments a LEFT JOIN services s ON s.id=a.service_id ORDER BY start_at DESC`).all();
 res.json(rows);
});
app.patch('/api/admin/services/:id', (req,res) => {
 // Protect this route with real admin authentication before public deployment.
 const {price,duration,name,active} = req.body || {};
 const result = db.prepare(`UPDATE services SET
   name=COALESCE(?,name), price=COALESCE(?,price), duration=COALESCE(?,duration),
   active=COALESCE(?,active) WHERE id=?`).run(name, price, duration, active, req.params.id);
 if (!result.changes) return res.status(404).json({error:'خدمت پیدا نشد.'});
 res.json({ok:true});
});
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`BARBER SAEED API listening on ${port}`));
